CREATE TABLE `reservas` (
  `idreserva` int NOT NULL,
  `nombrecliente` varchar(45) NOT NULL,
  `dni` varchar(45) NOT NULL,
  `idhotel` int NOT NULL,
  `idvuelo` int NOT NULL,
  PRIMARY KEY (`idreserva`),
  KEY `idhotel_idx` (`idhotel`),
  KEY `idvuelo_idx` (`idvuelo`),
  CONSTRAINT `idhotel` FOREIGN KEY (`idhotel`) REFERENCES `hotel` (`idhotel`),
  CONSTRAINT `idvuelo` FOREIGN KEY (`idvuelo`) REFERENCES `vuelos` (`idvuelo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci