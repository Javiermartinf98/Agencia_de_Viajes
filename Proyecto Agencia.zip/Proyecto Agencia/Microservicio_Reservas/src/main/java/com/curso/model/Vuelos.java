package com.curso.model;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * 
 * @author Javier
 *
 */
@Table(name="vuelos")
public class Vuelos 
{
	/**
	 * Atributos que tendra la clase Vuelos
	 * @param idvuelo idvuelo sera el identificador primary key de la bd
	 * @param compañia compañia es el nombre de la aerolinea
	 * @param fechavuelo fechavuelo cuando se realiza dicho vuelo
	 * @param precio precio es lo que cuesta el vuelo
	 * @param plazas plazas es el nunmero de plazas que existe
	 */
	private int idvuelo;
	@Column(name="compañia", nullable = false)
	private String compania;
	private Date fechavuelo;
	private Double precio;
	private int plazas;
	
	/**
	 * Constructor sin parametros
	 */
	public Vuelos() { }

	/**
	 * Constructor con parametros
	 */
	public Vuelos(int idvuelo, String compania, Date fechavuelo, Double precio, int plazas)
	{
		super();
		this.idvuelo = idvuelo;
		this.compania = compania;
		this.fechavuelo = fechavuelo;
		this.precio = precio;
		this.plazas = plazas;
	}

	/**
	 * Getters y Setter de los atributos de la clase vuelo
	 * @return
	 */
	public int getIdvuelo() {
		return idvuelo;
	}
	public void setIdvuelo(int idvuelo) {
		this.idvuelo = idvuelo;
	}

	public String getCompania() {
		return compania;
	}
	public void setCompania(String compania) {
		this.compania = compania;
	}

	public Date getFechavuelo() {
		return fechavuelo;
	}
	public void setFechavuelo(Date fechavuelo) {
		this.fechavuelo = fechavuelo;
	}

	public Double getPrecio() {
		return precio;
	}
	public void setPrecio(Double precio) {
		this.precio = precio;
	}

	public int getPlazas() {
		return plazas;
	}
	public void setPlazas(int plazas) {
		this.plazas = plazas;
	}
}
