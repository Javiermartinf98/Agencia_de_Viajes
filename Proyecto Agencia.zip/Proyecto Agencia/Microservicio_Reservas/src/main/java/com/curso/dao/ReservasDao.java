package com.curso.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.curso.model.Hotel;
import com.curso.model.Reservas;

/**
 * 
 * @author Javier
 *
 */

/**
 * Clase que gestiona la conexion con el JPARepository
 */
public interface ReservasDao extends JpaRepository<Reservas, Integer> 
{
	/**
	 * 	Query que muestra una consulta sobre los hoteles que esten disponibles
	 * @param disponible
	 * @return
	 */
	@Query(value="select ar.idreserva, ar.nombrecliente, ar.dni, ar.idvuelo, av.compañia, ar.idhotel, ah.nombre from agencia.reservas ar join"
			+ " agencia.vuelos av on(ar.idvuelo = av.idvuelo)"
			+ " join agencia.hotel ah on(ah.idhotel = ar.idhotel) where ah.nombre = ?",  nativeQuery = true)
	List<Reservas> verReservasXNomHotel(String nombre);
}
