package com.curso.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.curso.model.Reservas;
import com.curso.service.ReservasService;

/**
 * @author Javier
 *
 */

/**
 * La clase Controller es el encargado de gestionar las rutas, donde se lanzan las consultas
 */
@RestController
public class ReservasController 
{
	@Autowired
	ReservasService service;
	
	/**
	 * Metodo GET que muestra la lista de aquellas reservas que tienen realizadas a traves del nombre del hotel
	 * @param nombre
	 * @return
	 */
	//http://localhost:9091/reserva/{nombre} //poner nombre del hotel
	@GetMapping(value="reserva/{nombre}", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Reservas> verReservasXNomHotel(@PathVariable("nombre") String nombre) 
	{
		return service.verReservasXNomHotel(nombre);
	}
}
