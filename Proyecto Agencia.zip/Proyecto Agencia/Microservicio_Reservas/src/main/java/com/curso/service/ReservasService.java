package com.curso.service;

import java.util.List;

import com.curso.model.Reservas;
/**
 * 
 * @author Javier
 *
 */

/**
 * Interfaz donde se definen los metodos
 */
public interface ReservasService 
{
	/**
	 * Metodo que mira las reservas que existen segun el nombre del hotel que pongas, realizado con una Query
	 * @param nombre
	 * @return
	 */
	List<Reservas> verReservasXNomHotel(String nombre);
}
