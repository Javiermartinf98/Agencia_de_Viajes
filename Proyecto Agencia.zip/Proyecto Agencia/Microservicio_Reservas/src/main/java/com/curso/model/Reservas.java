package com.curso.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
/**
 * 
 * @author Javier
 *
 */
@Entity
@Table(name="reservas")
public class Reservas 
{
	/**
	 * Atributos que tiene la clase Reservas 
	 * @param idreserva isreserva es el identificador de la reserva y es primary key en la BD
	 * @param nombrecliente nombrecliente es el nombre del cliente que realiza la reserva
	 * @param dni dni es el dni del cliente
	 * @param idhotel idhotel es la foreign key de la tabla Hotel e identifica en que hotel se hace la reserva
	 * @param idvuelo idvuelo es la foreign key de la tabla Vuelos e identifica en que vuelo se hace la reserva
	 */
	@Id
	@Column(name="idreserva", nullable = false)
	private int idreserva;
	@Column(name="nombrecliente", nullable = false)
	private String nombrecliente; 
	@Column(name="dni", nullable = false)
	private String dni;
	@Column(name="idhotel", nullable = false)
	private int idhotel;
	@Column(name="nombre", nullable = false)
	private String nombre;
	@Column(name="idvuelo", nullable = false)
	private int idvuelo;
	@Column(name="compañia", nullable = false)
	private String compania;
	
	/**
	 * Constructor sin parametros
	 */
	public Reservas() { }

	/**
	 * Constructor con parametros
	 */
	public Reservas(int idreserva, String nombrecliente, String dni, int idhotel, int idvuelo) 
	{
		super();
		this.idreserva = idreserva;
		this.nombrecliente = nombrecliente;
		this.dni = dni;
		this.idhotel = idhotel;
		this.idvuelo = idvuelo;
	}
	
	
/*
	public Reservas(int idreserva, String nombrecliente, String dni, int idhotel, String nombre, int idvuelo,
			String compania) 
	{
		super();
		this.idreserva = idreserva;
		this.nombrecliente = nombrecliente;
		this.dni = dni;
		this.idhotel = idhotel;
		this.nombre = nombre;
		this.idvuelo = idvuelo;
		this.compania = compania;
	}
*/
	/**
	 * Getters y Setters de las clase Reserva
	 * @return
	 */
	public int getIdreserva() {
		return idreserva;
	}
	public void setIdreserva(int idreserva) {
		this.idreserva = idreserva;
	}

	public String getNombrecliente() {
		return nombrecliente;
	}
	public void setNombrecliente(String nombrecliente) {
		this.nombrecliente = nombrecliente;
	}

	public String getDni() {
		return dni;
	}
	public void setDni(String dni) {
		this.dni = dni;
	}

	public int getIdhotel() {
		return idhotel;
	}
	public void setIdhotel(int idhotel) {
		this.idhotel = idhotel;
	}

	public int getIdvuelo() {
		return idvuelo;
	}
	public void setIdvuelo(int idvuelo) {
		this.idvuelo = idvuelo;
	}

	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCompania() {
		return compania;
	}
	public void setCompania(String compania) {
		this.compania = compania;
	}	
}
