package com.curso.service;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.curso.dao.ReservasDao;
import com.curso.model.*;
/**
 * 
 * @author Javier
 *
 */

/**
 * Clase que implementa la interfaz ReservasService y en el que habra que implementar los metodos
 */
@Service
public class ReservasImpl implements ReservasService
{
	@Autowired
	ReservasDao dao;
	
	
	@Autowired
	RestTemplate template;
	
	private String url_vuelos = "http://localhost:8088/";
	private String url_hotel = "http://localhost:8787/";
	
	/**
	 * Metodo que lista las reservas del nombre del hotel(Realizado con una Query)
	 */
	@Override
	public List<Reservas> verReservasXNomHotel(String nombre) 
	{
		return dao.verReservasXNomHotel(nombre);
	}
}
