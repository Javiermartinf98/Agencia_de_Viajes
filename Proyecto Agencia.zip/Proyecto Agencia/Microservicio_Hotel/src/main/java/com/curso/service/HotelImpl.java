package com.curso.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.config.ConfigDataResourceNotFoundException;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.curso.dao.HotelDao;
import com.curso.model.Hotel;

/**
 * 
 * @author Javier
 *
 */

/**
 * Clase que implementa la interfaz HotelService y en el que habra que implementar los metodos
 */
@Service
public class HotelImpl implements HotelService
{
	@Autowired
	HotelDao dao;
	
	@Autowired
	RestTemplate template;
		
	/**
	 * Muestra los hoteles disponibles
	 */
	@Override
	public List<Hotel> HotelesDisponibles(String disponible) 
	{
		return dao.HotelesDisponibles(disponible);
	}

	/**
	 * Muestra los datos del hotel introducido
	 */
	@Override
	public Hotel UnHotel(String nombre)
	{
		return dao.UnHotel(nombre);
	}

	/**
	 * Inserta un nuevo hotel en la BD
	 */
	@Override
	public void AltaHotel(Hotel h) 
	{
		List<Hotel> mashoteles = new ArrayList<>();
		boolean encontrado = false;

		for(Hotel hotel : mashoteles)
		{
			if(hotel.getIdhotel() == h.getIdhotel())
			{
				encontrado = true;
				System.out.println("No puedes repetir una clave primaria");
			}
		}
		
		if(!encontrado)
		{
			mashoteles.add(new Hotel(h.getIdhotel(),h.getNombre(),h.getCategoria(),h.getPrecio(),h.getDisponible()));
			dao.save(h);
		}
	}

	/**
	 * Elimina un hotel de la base de datos segun el idhotel que se introduzca
	 */
	@Override
	public List<Hotel> EliminarHotel(int idhotel)
	{
		dao.deleteById(idhotel);
		return dao.findAll();
	}
}
