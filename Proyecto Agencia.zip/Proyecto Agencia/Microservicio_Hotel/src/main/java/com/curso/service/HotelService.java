package com.curso.service;

import java.util.List;

import com.curso.model.Hotel;

/**
 * 
 * @author Javier
 *
 */

/**
 * Interfaz donde se definen los metodos
 */
public interface HotelService
{
	/**
	 * Metodo que devuelve la lista de hoteles que estan disponibles
	 * @return
	 */
	List<Hotel> HotelesDisponibles(String disponible);
	
	/**
	 * Metodo que mostrara los datos de un hotel a partir de su nombre
	 * @param nombre
	 * @return
	 */
	Hotel UnHotel(String nombre);
	
	/**
	 * Metodo que dara de alta un nuevo hotel
	 * @param h
	 * @return
	 */
	void AltaHotel(Hotel h);
	
	/**
	 * Metodo que elimina el hotel segun el id que pongas y despues los lista
	 * @param idpokemon
	 * @return
	 */
	List<Hotel> EliminarHotel(int idhotel);
}
