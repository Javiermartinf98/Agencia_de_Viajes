package com.curso.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.curso.model.Hotel;
import com.curso.service.HotelService;

/**
 * @author Javier
 *
 */

/**
 * La clase Controller es el encargado de gestionar las rutas, donde se lanzan las consultas
 */
@RestController
public class HotelController
{
	@Autowired
	HotelService service;
	
	/**
	 * Metodo GET que muestra si pones si: muestra los hoteles disponibles y si pones no: muestra los que no estan disponibles
	 * @param disponible
	 * @return
	 */
	//http://localhost:8787/hoteles/{disponible} //poner si o no
	@GetMapping(value="hoteles/{disponible}", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Hotel> HotelesDisponibles(@PathVariable("disponible") String disponible)
	{
		return service.HotelesDisponibles(disponible);
	}
	
	/**
	 * Metodo GET que muestra los datos del hotel que pongas. Por su nombre
	 * @param nombre
	 * @return
	 */
	//http://localhost:8787/hotel/{nombre}
	@GetMapping(value="hotel/{nombre}", produces = MediaType.APPLICATION_JSON_VALUE)
	public Hotel UnHotel(@PathVariable("nombre") String nombre)
	{
		return service.UnHotel(nombre);
	}
	
	/**
	 * Metodo POST en el que se inserta un nuevo hotel
	 * @param h
	 */
	//http://localhost:8787/hotel
	@PostMapping(value="hotel", consumes= MediaType.APPLICATION_JSON_VALUE)
	public void AltaHotel(@RequestBody Hotel h)
	{
		service.AltaHotel(h);
	}
	
	/**
	 * Metodo DELETE en el que se elimina un hotel
	 * @param idhotel
	 * @return
	 */
	//http://localhost:8787/hotel/{idhotel}
	@DeleteMapping(value="hotel/{idhotel}", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Hotel> EliminarHotel(@PathVariable("idhotel") int idhotel)
	{
		return service.EliminarHotel(idhotel);
	}
}
