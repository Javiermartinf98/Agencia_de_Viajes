package com.curso.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * 
 * @author Javier
 *
 */
@Entity
@Table(name="hotel")
public class Hotel
{
	/**
	 * Atributos que va a tener la clase Hotel
	 * @param idhotel idhotel -> primary key en la base de datos(identificador)
	 * @param nombre nombre que tendra el hotel
	 * @param categoria categoria es la reputacion que tiene el hotel
	 * @param precio precio es lo que cuesta dicho hotel
	 * @param disponible disponible es la varibale que dice si esta ocupado o no
	 */
	@Id
	private int idhotel;
	@Column(name="nombre", nullable = false)
	private String nombre;
	@Column(name="categoria", nullable = false)
	private String categoria;
	@Column(name="precio", nullable = false)
	private Double precio;
	@Column(name="disponible", nullable = false)
	private String disponible;
	
	/**
	 * Constructor vacio de la clase hotel
	 */
	public Hotel() { }

	/**
	 * Constructor con todas las variables de la clase hotel
	 */
	public Hotel(int idhotel, String nombre, String categoria, Double precio, String disponible)
	{
		super();
		this.idhotel = idhotel;
		this.nombre = nombre;
		this.categoria = categoria;
		this.precio = precio;
		this.disponible = disponible;
	}

	/**
	 * Getters y setter de las variables de la clase hotel
	 * @return
	 */
	public int getIdhotel() {
		return idhotel;
	}
	public void setIdhotel(int idhotel) {
		this.idhotel = idhotel;
	}

	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public Double getPrecio() {
		return precio;
	}
	public void setPrecio(Double precio) {
		this.precio = precio;
	}

	public String getDisponible() {
		return disponible;
	}
	public void setDisponible(String disponible) {
		this.disponible = disponible;
	}
}
