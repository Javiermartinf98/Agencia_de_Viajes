package com.curso.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.curso.model.Vuelos;
import com.curso.service.VuelosService;

/**
 * @author Javier
 */

/**
 * La clase Controller es el encargado de gestionar las rutas, donde se lanzan las consultas
 */

@RestController
public class VuelosController 
{
	@Autowired
	VuelosService service;
	
	/**
	 * Metodo GET que muestra aquellos vuelos que tengan plazas disponibles, al insertar las plazas que quieres ocupar
	 * @param plazareservada
	 * @return
	 */
	//http://localhost:8088/vuelos/{plazareservada}
	@GetMapping(value="vuelos/{plazareservada}", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Vuelos> ReservarPlazas(@PathVariable("plazareservada") int plazareservada) 
	{
		return service.ReservarPlazas(plazareservada);
	}
	
	/**
	 * Metodo PUT que actualiza por idvuelo introducido, las plazas que quieras ocupar
	 * @param idvuelo
	 * @param numplazas
	 */
	//http://localhost:8088/vuelo/{id}/{plazas}
	@PutMapping(value="vuelo/{idvuelo}/{plazas}")
	void ActualizarVuelos(@PathVariable("idvuelo") int idvuelo,@PathVariable("plazas") int numplazas)
	{
		service.ActualizarVuelos(idvuelo, numplazas);
	}
	
	/**
	 * Metodo DELETE que elimina un vuelo
	 * @param idvuelo
	 * @return
	 */
	//http://localhost:8088/vuelo/{idvuelo}
	@DeleteMapping(value="vuelo/{idvuelo}", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Vuelos> EliminarVuelo(@PathVariable("idvuelo") int idvuelo)
	{
		return service.EliminarVuelo(idvuelo);
	}
	
	/**
	 * Metodo POST que inserta unn vuelo en la BD
	 * @param v
	 */
	//http://localhost:8088/vuelo
	@PostMapping(value="vuelo", consumes= MediaType.APPLICATION_JSON_VALUE)
	public void AltaVuelo(@RequestBody Vuelos v)
	{
		service.AltaVuelo(v);
	}
	
	/**
	 * Metodo GET que te muestra todos los vuelos disponibles
	 * @return
	 */
	//http://localhost:8088/vuelos
	@GetMapping(value="vuelos")
	public List<Vuelos> AllVuelos()
	{
		return service.AllVuelos();
	}
}
