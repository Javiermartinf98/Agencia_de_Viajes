package com.curso.service;

import java.util.List;
import com.curso.model.Vuelos;

/**
 * 
 * @author Javier
 *
 */

/**
 * Interfaz donde se definen los metodos
 */
public interface VuelosService 
{
	/**
	 * Metodo que devuelve una lista de los vuelos que tengan plazas disponibles
	 * @param plazareservada numero de plazas que se reservan
	 * @return
	 */
	List<Vuelos> ReservarPlazas(int plazareservada);
	
	/**
	 * Metodo que actualiza segun el idvuelo que ingreses, actualiza las plazas, que pongas (restando asi las que estan puestas en la bd por defecto)
	 * @param idvuelo
	 * @param numplazas
	 */
	void ActualizarVuelos(int idvuelo, int numplazas);
	
	/**
	 * Metodo que elimina un vuelo por su idvuelo
	 * @param idvuelo
	 * @return
	 */
	List<Vuelos> EliminarVuelo(int idvuelo);
	
	/**
	 * Metodo que ingresa un vuelo en la bd
	 * @param v
	 */
	void AltaVuelo(Vuelos v);
	
	/**
	 * Metodo que muestra todos los vuelos
	 * @return
	 */
	List<Vuelos> AllVuelos();
}
