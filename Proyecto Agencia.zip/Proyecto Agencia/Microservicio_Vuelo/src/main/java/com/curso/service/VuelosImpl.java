package com.curso.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.curso.dao.VuelosDao;
import com.curso.model.Vuelos;

/**
 * 
 * @author Javier
 *
 */

/**
 * Clase que implementa la interfaz VuelosService y en el que habra que implementar los metodos
 */

@Service
public class VuelosImpl implements VuelosService
{
	@Autowired
	VuelosDao dao;
	
	@Autowired
	RestTemplate template;
	
	String url="http://localhost:8088/";
	
	@Override
	public List<Vuelos> ReservarPlazas(int plazareservada) 
	{
		ArrayList<Vuelos> misvuelos = new ArrayList();
		
		for(Vuelos v : dao.findAll())
		{
			if(v.getPlazas() > plazareservada)
			{
				v.setPlazas(v.getPlazas()-plazareservada);
				
				misvuelos.add(new Vuelos(v.getIdvuelo(),v.getCompania(),v.getFechavuelo(),v.getPrecio(),v.getPlazas()));
			}
		}
		return misvuelos;
	}

	@Override
	public void ActualizarVuelos(int idvuelo, int numplazas)
	{
		Optional<Vuelos> v = dao.findById(idvuelo);
		
		if(v.get().getPlazas() > numplazas)
		{
			v.get().setPlazas(v.get().getPlazas()-numplazas);
			dao.save(v.get());
		}
		else
		{
			System.out.println("No existen plazas disponibles para este vuelo");
		}
	}

	@Override
	public List<Vuelos> EliminarVuelo(int idvuelo)
	{
		dao.deleteById(idvuelo);
		return dao.findAll();
	}

	@Override
	public void AltaVuelo(Vuelos v)
	{
		List<Vuelos> masvuelos = new ArrayList<>();
		boolean encontrado = false;
		
		for(Vuelos vuelo : masvuelos)
		{
			if(v.getIdvuelo() == vuelo.getIdvuelo())
			{
				encontrado = true;
				System.out.println("No puedes ingresar el vuelo, ya que duplicas la PRIMARY KEY");
			}
		}
		if(!encontrado)
		{
			//formato fecha YYY-MM-D
			v.setFechavuelo(new Date());
			
			masvuelos.add(new Vuelos(v.getIdvuelo(),v.getCompania(),v.getFechavuelo(),v.getPrecio(),v.getPlazas()));
			dao.save(v);
		}
	}

	@Override
	public List<Vuelos> AllVuelos() 
	{
		return dao.AllVuelos();
	}
	
	
}
