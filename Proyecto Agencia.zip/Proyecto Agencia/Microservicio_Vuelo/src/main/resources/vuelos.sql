CREATE TABLE `vuelos` (
  `idvuelo` int NOT NULL,
  `compañia` varchar(45) NOT NULL,
  `fechavuelo` date NOT NULL,
  `precio` double NOT NULL,
  `plazas` int NOT NULL,
  PRIMARY KEY (`idvuelo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci